nome = input("Digite seu nome: ")

peso = float(input("Digite seu peso: "))
altura = float(input("Digite sua altura: "))


imc = peso / (altura ** 2)

if imc > 30.:
    print("Cuidado com a saúde! ")
elif imc < 30.:
    print("Tudo ok. ")
    print("Faixa de IMC        | Tabela de verificação:               |")

print("| < 18.5              | Abaixo do peso                 |")
print("| 18.5 – 24.9         | Peso normal                    |")
print("| 25.0 – 29.9         | Sobrepeso                      |")
print("| 30.0 – 34.9         | Obesidade Grau I               |")
print("| 35.0 – 39.9         | Obesidade Grau II              |")
print("| ≥ 40.0              | Obesidade Grau III (mórbida)   |")
nome = input("Digite novamente seu nome para o cálculo do IMC: ")

peso = float(input("Digite seu peso: "))
altura = float(input("Digite sua altura: "))

imc = peso / (altura ** 2)
match peso:
    case IMC if IMC < 18.5:
        print(f" Olá {nome}. Seu peso foi de {IMC:.2f}KG e você esta abaixo do peso.")
    case IMC if IMC < 18.5 < 24.9:
        print(f" Olá {nome}. Seu peso foi de {IMC:.2f}KG e seu peso é normal")
    case IMC if IMC < 25.0 < 29.9:
        print(f"Olá {nome}. Seu peso foi de {IMC:.2f}KG sobrepeso.")
    case IMC if IMC < 30.0 < 34.9:
        print(f"Olá {nome}. Seu peso é de {IMC:.2f}KG e você tem, obesidade grau I")
    case IMC if IMC < 35.0 < 39.9:
        print(f"Olá {nome}. Seu peso é de {IMC:.2f}KG e você tem obesidade grau II")
    case IMC if IMC >= 40.0:
        print(f"Olá {nome}. Seu peso é de {IMC:.2f}KG e você tem obesidade grau III (Obesidade mórbida)")
