opcao = input('Digite "M" para amanhã ou qualquer tecla para tarde ').strip().lower()
if opcao == "M":
    print("Bom dia")
else:
    print("Boa tarde")