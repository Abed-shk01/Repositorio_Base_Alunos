senha_usuario = "1234"

senha = input("Digite sua senha: ")
if senha == senha_usuario:
    print("acesso liberado")
else:
    print("Acesso negado. Tente novamente")