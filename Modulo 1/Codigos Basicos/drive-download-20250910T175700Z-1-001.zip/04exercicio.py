nome = input("Digite seu nome")
if nome == "carlos":
    print("Você está na lista")
else:
    print("Nome não encontrado")