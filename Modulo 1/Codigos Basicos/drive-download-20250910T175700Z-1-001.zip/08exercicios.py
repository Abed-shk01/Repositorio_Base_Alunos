numero = int(input("Digite um número: "))

if numero % 5 == 0:
    print("Múltiplo de 5")
else:
    print("Não é múltiplo de 5")