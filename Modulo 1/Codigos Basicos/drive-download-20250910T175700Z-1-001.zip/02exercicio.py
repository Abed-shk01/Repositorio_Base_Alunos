idade = int(input("Qual sua idade"))
if idade >= 18:
    print("maior de idade")
else:
    print("menor de idade")