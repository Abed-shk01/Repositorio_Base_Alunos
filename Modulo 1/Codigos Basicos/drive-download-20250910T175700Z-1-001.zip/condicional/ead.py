nome = input("Digite o nome do funcionário: ")
vendas = float(input("Digite o valor total das vendas do mês: "))
dias = int(input("Digite o número de dias úteis trabalhados: "))


if vendas > 10000 and dias >= 20:
    bonus = vendas * 0.10   # 10% das vendas ue e o calculo do bonus
else:
    bonus = vendas * 0.03   # 3% das vendas que é a conta 


print("Funcionário:", nome)
print("Valor total das vendas:", vendas)
print("Dias trabalhados:", dias)
print("Bônus do mês:", bonus)