print("menu pizzaria")
print("1- marguerita")
print("2- Frango")
print("3- quatro quiejos")
print("4- portuguesa")
pizza = int(print("Escolha um sabor"))

match pizza:
    case 1: 
        print("Produto: marguerita| R$: 50,00")
    case 2:
        print("Produto 2: frango| R$: 100,00")
    case 3:
        print("Produto quatro queijos| R$: 200,00")
    case 4:
        print("Produto| portuguesa R$ 120,00")
        