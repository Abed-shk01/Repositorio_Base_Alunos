#Crie um codigo utilizando match case que analise as notas dos alunos:
# 1)peça ao usuario 2 notas
# 2) calcule a media e calssifique ela em:
# 0 a 4 = reprovado
# 5 e 6 = recuperação
# 7 a 10 = aprovado
        

nome = input("Digite o nome doa aluno")
nota1 = float(input("Digite sua primeira nota"))
nota2 = float(input("Digite sua segunda nota"))
nota3 = float(input("Digite sua terceira nota"))
nota4 = float(input("Digite sua quarta nota"))

# calculo da media
media = (nota1 + nota2 + nota3 + nota4)

# condicional
match media:
    case media if media < 5:
        print(f"Aluno {nome}")
        print(f"Sua media foi {media:.2f} e voce esta reprovado.")
    case media if 5 <= media < 7:
        print(f"O aluno {nome} está de recuperação")
        print(f"Sua média é de {media:.2f} e você esta de recuperação")
    case media if 7 <= media <= 10:
        print(f"Aluno : {nome}")
        print(f"Sua media foi {media:.2f} e você foi apovado. ")
    case _: 
        print("Nota inálida. Verifique as informações.")