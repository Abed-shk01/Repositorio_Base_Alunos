# Crie um código python que solicite ao ususarioo codigo de um produto
# produto
print("Menu de produtos")
print("1- café")
print("2- cha")
print("3- suco")
print("4 refri")
print("5- agua")
codigo = int(input("Digite o codigo do produto"))

match codigo:
    case 1:
        print("Produto: café 500 g: R$ 36,00")
    case 2:
        print("Produto: cha 100g: R$8,00 ")
    case 3:
        print("Produto: suco 300g: R$ 10,00")
    case 4:
        print("Produto: Refri 400g : R$: 13,00")
    case 5:
        print("Produto: agua 200g: R$: 20,00")
        