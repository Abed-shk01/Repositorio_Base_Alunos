# Crie um programa que
# 1) Peça ao usuário que digite um numero de 1 a 7 para indicaros dias da semana
# 2) Use match case para exibir o nomecorrespondente ao número :
# 1- Domingo
# 2- segunda feira
# 3 - terça feira
# 4- quarta
# 5- quinta
# 6- Sexta
# 7_ sabado
dia = int(input("Digite um numero de 1 a 7:"))
print("""Domingo
segunda feira
terça feira
quarta
quinta
Sexta
sabado""")
match dia:
    case 1:
        print("È domngo. Bom inicio de semana.")
    case 2:
        ("Hoje é segunda feira.Boa semana.")
    case 3:
        print("Hoje é terça feira.")
    case 4:
        print("Hoje é quarta feira")
    case 5:
        print("Hoje é quinta feira.")
    case 6:
        print("Hoje e sexta feira. sextou!")

        #Crie um codigo utilizando match case que analise as notas dos alunos:
        # 1)peça ao usuario 2 notas
        # 2) calcule a media e calssifique ela em:
        # 0 a 4 = reprovado
        # 5 e 6 = recuperação
        # 7 a 10 = aprovado
            