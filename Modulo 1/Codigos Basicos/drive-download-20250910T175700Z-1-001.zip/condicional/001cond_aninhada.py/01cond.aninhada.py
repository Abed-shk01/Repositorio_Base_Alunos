#1. Identificação de múmero positivo, negativo ou zero
# Crie um código em python que leia se ele é positivo ou negativoou zero
# 1) entrada de dados
num = int(input("Digite um número inteiro"))
# 2) Condicional para verificar se o número é zero
if num >= 0:
    # Condicional para checar se o número é zero
    if num == 0:
        print("O número digitado é zero.")
    else: # informa que o número é positivo
        print(f"O número {num} é positivo.")
        # Se o if for falso, entra no else, e numero negativo
else:
    print(f"O número {num} é negativo")