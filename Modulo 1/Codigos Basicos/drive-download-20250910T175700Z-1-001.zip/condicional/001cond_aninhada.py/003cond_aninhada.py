# 3. Classificação por idade
# Faça um programa que leia a idade de uma pessoa e classifique a em:
# criança: menor que 12 anos
# adolescente : entre 12 e 17 anos
# adulto : maior ou igual a 18 anos
# Utilize condicional aninhada
idade = int(input("por favor informe sua idade"))
if idade > 0:
    if idade >= 18:
        print(f"Você tem {idade} e tem idade para ver o filme")
    elif 12 <= idade <= 17:
          print(f"Você tem {idade} e é um adolescente ")
    else: 
            print(f"Você tem {idade} e é uma criança")
else:
    print("Idade não pode ser negativa, digite uma idade valida.")