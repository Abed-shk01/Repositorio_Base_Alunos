# Tipo de triangulo
# Crie um porgrama que receba os 3 lados de um triangulo
# Verfique se os lados formam um triangulo
# Equilatero (todos os lados são iguais)
# Isoceles ( dois lados iguais)
# Escaleno (todos os lados diferentes)

a = int(input("Digite o valor do lado a"))
b = int(input("Digite o valor do lado b"))
c = int(input("Digite o valor do lado c"))
 # Verificar se os lados formam um triangulo
if a + b > c and a + c > b and b + c > a: # condição para formação do triangulo   
    if a == b:
      if b == c:
        print(f'os lados do trinagulo são {a}, {b} e {c}: triangulo equilatero')
      else:
        print(f"Os lados do triângulo são {a}, {b} e {c}: Isoceles")
    else: # nao e possivel formar um triangulo
      if b == c or a == c:
        print(f"Os lados do triângulo são {a}, {b} e {c}: triângulo isoceles.")
      else:
       print(f"Os lados do triângulo são {a} {b} e {c}: triângulo escaleno.")
else:
  print('Os lados não formam um triângulo válido.')
      