# 2.Paridadee tamanho do núemro

# Crie um código que receba um número inteiro e informe:
# - se é par ou impar
# - e, ao mesmo tempo, se é maior ou menor ou igual a 10.
# Utilize condicionais aninhadas para organizar as verificações.

num1 = int(input("Digite um número"))
if num1 % 2 == 0:
    if num1 >= 10:
        print("é maior que dez")
        print(f"Este número {num1} é par")
    else:
        print("é menor que dez")
        print(f"Este número é par")
else:
    if num1 <= 10:
        print(f" o numero {num1} é menor que dez")
        print(f"Este número {num1} é impar")
    else:
        print("é menor que dez")
        print(f"Este número é menor que dez")

    print(f"Este número {num1} é impar")