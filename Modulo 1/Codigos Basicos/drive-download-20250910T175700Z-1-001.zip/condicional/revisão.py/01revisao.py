#Atividade do calculo de quadrado e cubo
num1 = int(input("Digite um número: "))
cubo = num1 ** 3
if num1 > 0: # Condição para verificar se o número é inteiro e positivo
    if num1 % 2 == 0: # Checar se o n° é par
        quadrado = num1 ** 2 # Calculo do quadrado do número
        print("O quadrado do número {} é {}" .format(num1, quadrado)) # nova maneira de formatar
        print(f"O quadrado do número {num1} é {quadrado}")
    else: 
        cubo == num1 ** 3 #Calculo do cubo do numero
        print(("O cubo do número {} é {}.").format(num1, cubo))
else:
    print("Número {} não é positivo.".format(num1))
