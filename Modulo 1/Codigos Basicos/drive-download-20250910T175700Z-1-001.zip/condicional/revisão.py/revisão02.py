# Atividade da senha
usuario1 = "Fábio"
senha = "1234"

usuario2 = "joão"
senha1 = "4321"

login = input("informe o seu login: ").strip().lower
senha_entrada = input("Informe sua senha: ").strip()

if (login == usuario1 and senha_entrada == senha) or (login == usuario2 and senha_entrada == senha1):
    print("Acesso liberado")
else:
    print("Senha incorreta")