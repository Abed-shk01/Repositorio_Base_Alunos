#Blak friday

print("Tabela de formas de pagamento")
print("1-á vista")
print("2-cartão debito")
print("3-cartao de credito(vencimento)")

valor_venda = float(input("informe o valor total da venda é de R$: "))
forma_pagamento = input("informe a forma de pagamento")

if forma_pagamento == 1:
    valor_final  = valor_venda * 0.85
    print('Obrigado pela sua compra, você recebeu um desconto e o valor final é R${}'.format(valor_final))
elif forma_pagamento == "2":
    valor_final = valor_venda * 0.95
    print("obrigado pela sua compra, você recebeu um desconto e o valor final é{}".format(valor_final))
else:
    print("Digite uma opção de pagamento válida.")