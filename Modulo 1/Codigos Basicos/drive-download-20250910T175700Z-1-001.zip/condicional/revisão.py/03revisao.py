#Atividade do aumento

# 1) entrada de dados
salario = float(input("Informe seu salário mensal: "))
cargo = input("Por favor informe seu cargo").strip().lower()

# 2) Salários
programador = 10000
analista_sistema = 70000
analista_cargo = 12000
salario_atual = salario 

if cargo == "programador":
    salario = float(input("Informe seu salario mensal R$ : "))
    salario_novo = salario * 1.30
    print("o novo salário do programador é R$ {}".format(salario_atual))
elif cargo == "analista de sistemas":
    salario = float(input("Informe seu salario mensal R$: "))
    salario_novo = salario * 1.20
    print("o salario novo do analista é de R$ {}.".format(salario_novo))
elif cargo == "analista de dados":
    salario = float(input("Informe seu salario mensal R$: "))
    salario_novo = salario * 1.15
    print("o novo salário do analista de dados é R$ : ")    
else:
    print("Cargo não encontrado")