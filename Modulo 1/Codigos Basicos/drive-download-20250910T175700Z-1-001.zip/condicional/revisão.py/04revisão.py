apresentador = input('informe o sobrenome do seu apresentador preferido: ').strip().lower()

if apresentador == "pinheiro" or apresentador == "araujo":
    print("Esses é um apresentador do Bom dai nação")
elif apresentador == "bonner" or apresentador == "vasconselos":
    print("Esse é um apresentador do jornal brasileiro.")
else:
    print("Apresentador desconhecido")