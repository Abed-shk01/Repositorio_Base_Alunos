# como remover todos os elementos de uma lista
lista =  [1, 2, 3]
print(lista)

lista.clear