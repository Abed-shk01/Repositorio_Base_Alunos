# como identificar a posição de um elementoem uma lista

# . index() retorna o indice da primeira ocorrencia de um valor

lista = [1, 2, 3]
print(lista.index(2))