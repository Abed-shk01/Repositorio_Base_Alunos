# como adicionar elemento em uma posição especifica da lista?

# .append() Adicione um item no final da lista
# lista = [1, 2]
# lista,append(3)  [1, 2, 3]

diversos = [1,'banana', 'mouse', 23.5, 'aeiou', True, [1,2,3,4,5]]
diversos.append(5)
print(diversos)