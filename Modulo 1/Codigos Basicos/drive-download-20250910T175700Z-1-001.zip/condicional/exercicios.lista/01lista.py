# Crie uma lista vazia chamada frutas.
# Peça para o usuario digitar o nome de uma fruta e use .append()