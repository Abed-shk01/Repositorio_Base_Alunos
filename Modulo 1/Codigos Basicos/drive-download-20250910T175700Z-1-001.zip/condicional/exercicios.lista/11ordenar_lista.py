# Como ordenar uma lista
# .sort() Ordena os itens da lista(ordemc rescente por padrão)
#lista = [3,1,2]; lista.sort() [1, 2, 3]

lista_desordenada = [1,23,0,5,3,99,34,7]
print(lista_desordenada)

lista_desordenada.sort()
print(lista_desordenada)

letras = ['m', 'b', 'a', 'p']
letras.sort() # ordena as letras em ordem alfabeica
