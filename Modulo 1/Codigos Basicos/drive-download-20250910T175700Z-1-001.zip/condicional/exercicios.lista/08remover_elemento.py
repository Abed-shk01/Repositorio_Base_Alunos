# Como remover um elemento da lista?
# .pop()  Remove e retorna o último item (ou item de indice)
# lista = [1, 2, 3]
#lista.pop() 3, lista fica [1, 2]
diversos = [1,'banana', 'mouse', 23.5, 'aeiou', True, [1,2,3,4,5]]

diversos.pop()