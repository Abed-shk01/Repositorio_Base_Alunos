#LISTA

#SINTAXE
#como criar uma lista?
#usamos colchetes [] para definir uma lista, separandoos elementos por virgulas.
#nome_da_lista = [elemento_1, elemento_2]

diversos = [1, 'banana', 'mouse', 23.5, 'aeiou', True, [1,2,3,4,5]]
# Isso mostra que listas são felxiveis e podem misturar tipos de dados.
print(diversos)#lista total
print(diversos[3])#a lista começa com indice
print(diversos[-1])#pegar o ultimo elemento quando eu nao sei o tamanho da lista
print(diversos[6]) # pegar elemento especifico
print(diversos[-1][2])# pegar um elemento da lista em outra lista