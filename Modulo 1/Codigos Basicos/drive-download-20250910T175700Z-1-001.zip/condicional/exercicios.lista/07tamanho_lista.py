# Como saber o tamanho da lista

diversos = [1,'banana', 'mouse', 23.5, 'aeiou', True, [1,2,3,4,5]]
print(len(diversos))
