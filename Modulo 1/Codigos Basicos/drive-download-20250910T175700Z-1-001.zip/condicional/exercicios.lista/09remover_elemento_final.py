# Como remover um elementode uma lista?
# .remove() remove a primeira ocorrencia de um valor
#lista =  [1, 2, 3]
# lisa.remove(2) [1, 3]
numeros = [1,2,3,4,5,6,7,5]
numeros.remove(5)
print(numeros)