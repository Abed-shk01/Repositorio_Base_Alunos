# Como saber o tipo o elemento?
# type (elemento)

diversos = [1,'banana', 'mouse', 23.5, 'aeiou', True, [1,2,3,4,5]]
print(type (diversos))
print(type(diversos[3])) # para saber qual o tipo de elemento