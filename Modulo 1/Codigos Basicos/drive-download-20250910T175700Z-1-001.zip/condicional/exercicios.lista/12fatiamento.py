# Como fatiar uma lista
# podemos extrair "pedaços" da lista usando [inicio:fim:passo]:

letras = ['a','b','c','d','e']
print(letras[1:4])  # ['b 'c' 'd'] indices 1 ao 3
print(letras[::2]) # quando não se coloa nada ele pula de 2 em 2
