#Como copiar uma lista
#.copy()