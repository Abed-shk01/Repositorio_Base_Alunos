#como eu sei quantas vezes aparece um elmento de uma lista

lista = [1,2,3,4,5]
print(lista.count(2))