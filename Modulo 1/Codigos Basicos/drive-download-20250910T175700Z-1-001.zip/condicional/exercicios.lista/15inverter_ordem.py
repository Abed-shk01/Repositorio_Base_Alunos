# como inverter a ordem de uma lista

# .reverse()  inverte a ordem dos itens da lista

lista = [1,2,3]
print(lista)