 # Condicional Simples
 # Para condições em Python utilizamos a "if" que significa se em português
# Com condicional, você  consegue executar
idade = int(input("Qual sua idade"))
if idade >= 18:
    print("maior de idade")
else:
    print("menor de idade")