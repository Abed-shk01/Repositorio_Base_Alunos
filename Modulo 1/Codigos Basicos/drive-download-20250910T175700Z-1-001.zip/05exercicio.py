conta = float(input("Digite o valor da conta R$: "))
if conta >= 100:
    print(f"Origada por sua visita sua conta é R$: ")
else: conta_final = conta*1.05
print(f"Obrigado por vr sua conta deu R$: {conta_final:2f}")