num1 = float(input("Digite um número"))
num2 = float(input("Digite outro número"))
if num1 == num2:
    print(f"O numero {num1} é igual ao {num2}")
else:
    print(f"O numero {num1} é diferente de {num2}")