convite = input("Você foi convidado? (sim ou não)")
if convite == convite:
    print("você está autorizado")
else:
    print("você não foi autorizado")